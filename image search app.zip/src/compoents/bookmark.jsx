import React from 'react'

function Bookmark() {
  return (
    <div>Bookmark</div>
  )
}

export default Bookmark